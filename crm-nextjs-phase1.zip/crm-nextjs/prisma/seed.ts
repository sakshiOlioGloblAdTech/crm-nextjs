import { PrismaClient } from "@prisma/client";
import bcrypt from "bcryptjs";

const prisma = new PrismaClient();

async function main() {
  // Create super admin
  const hashedPassword = await bcrypt.hash("admin123", 12);

  await prisma.user.upsert({
    where: { email: "admin@crm.com" },
    update: {},
    create: {
      name: "Super Admin",
      email: "admin@crm.com",
      password: hashedPassword,
      role: "SUPER_ADMIN",
    },
  });

  // Default settings row
  await prisma.setting.upsert({
    where: { id: 1 },
    update: {},
    create: {
      email: "admin@crm.com",
      deliveryFee: 50,
      defaultDeliveryFee: 50,
    },
  });

  // Seed cancellation reasons (from your PHP data)
  const cancellationReasons = [
    "Changed my mind",
    "Found a better price elsewhere",
    "Ordered by mistake",
    "Delivery time too long",
    "Product no longer needed",
  ];

  for (const reason of cancellationReasons) {
    await prisma.cancellationReason.create({
      data: { reason, status: true },
    });
  }

  // Seed return reasons
  const returnReasons = [
    "Defective product",
    "Wrong item delivered",
    "Product not as described",
    "Damaged during shipping",
    "Changed my mind",
  ];

  for (const reason of returnReasons) {
    await prisma.returnReason.create({
      data: { reason, status: true },
    });
  }

  console.log("✅ Seed complete");
  console.log("   Admin: admin@crm.com / admin123");
}

main()
  .catch(console.error)
  .finally(() => prisma.$disconnect());
